# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "Laptop"
__date__ = "$22.11.2018 15:47:23$"

# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "Florian Klaus & Daniel Paasch"
__date__ = "$19.11.2018 14:06:27$"

import shodan
import datetime
import time


SHODAN_API_KEY = "7UKxZkBedvjVWkeOA3q8XLFS9bEwu7lw"

api = shodan.Shodan(SHODAN_API_KEY)
time = time.time()
ts = datetime.datetime.fromtimestamp(time).strftime('%d_%m_%Y_%H_%M_%S')

def write_shodan_entrys(abfrage_parameter):
# Wrap the request in a try/ except block to catch errors
    try:
        #Eingabe User
        #query = input("Bitte geben Sie ihre Anfrage ein: ")
        
        # Search Shodan
        results = api.search(abfrage_parameter)
    except shodan.APIError. e:
            print('Error: {}'.format(e))
        
        # Show the results
    print('Results found: {}'.format(results['total']))
    for result in results['matches']:
        file = open(ts + ".txt","a")
        #file.write("/n. result")
        file.write('\nIP: {}'.format(result['ip_str']))
        file.write('\nPort: {}'.format(result['port']))
        file.write('\nOrganisation: {}'.format(result['org']))
        file.write('\nBetriebsystem: {}'.format(result['os']))
        file.write('\nLand: {}'.format(result['location']))
        file.write('')
        file.write('\n')
                     

