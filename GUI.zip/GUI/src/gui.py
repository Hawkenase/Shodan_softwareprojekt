# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "Florian Klaus und Daniel Paasch"
__date__ = "$22.11.2018 13:40:24$"

from Softwareprojekt import *
from Kamerka_module import *
from tkinter import *
from tkinter import messagebox

fenster = Tk()
fenster.title("Shodan")
fenster.geometry("800x500")


def button_suchen():
    abfrage_text = eingabefeld.get()
    if (abfrage_text == ""):
        welcome_label.config(text="Es wird eine Eingabe benoetigt")
    else:
        abfrage = abfrage_text
        write_shodan_entrys(abfrage)
        print(abfrage)

def button_eingabe_loeschen():
    eingabefeld.delete(first=0, last=99)
        
def action_get_info_dialog():
    m_text = "\
    *************************************************\n\
    Autoren:       Florian Klaus und Daniel Paasch\n\
    Seminargruppe:   FO16w3-B         FO16w5-B\n\
    Aufgabe:        Softwareprojekt WS 18/19 \n\
    Dozent:         Prof. Dr. Dirk Pawlaszcyk \n\
    *************************************************"
    messagebox.showinfo(message=m_text, title="Info")

def button_vorlagen_1():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"Webcam")    
def button_vorlagen_2():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"webcam city:dresden")
def button_vorlagen_3():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"Minecraft Server port:25565 city:chemnitz")
def button_vorlagen_4():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"country:de os:windows xp")
def button_vorlagen_5():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"org:siemens os:windows xp")
def button_vorlagen_6():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"org:FBI")
def button_vorlagen_7():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"org:blizzard")
def button_vorlagen_8():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"os:windows xp")
def button_vorlagen_9():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"port:554 has_screenshot:true")
def button_vorlagen_10():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"port:8333 country:DE")
def button_vorlagen_11():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"ftp port:21 city:mittweida")
def button_vorlagen_12():
    eingabefeld.delete(first=0, last=99)
    eingabefeld.insert(0,"port:69 city:mittweida")

                                                                          
def button_kamenka_webcams_germany():
    abfrage= "Webcams Deutschland"

menuleiste = Menu(fenster)                                                  #Erstellen der Menueleiste
info_menu = Menu(menuleiste, tearoff=0)
info_menu.add_command(label="Entwickler", command=action_get_info_dialog)

abfrage_label = Label(fenster, text="Bitte geben Sie ihre Suchanfrage ein") #Label Suchfeld
welcome_label = Label(fenster)
                                                                            #Erstellen des Dropoff-Meues fuer vorgegebene
vorlagen_menu = Menu(menuleiste, tearoff=0)                                 #Abfragen
vorlagen_menu.add_command(label="Webcams -Weltweit-", command=button_vorlagen_1)
vorlagen_menu.add_command(label="Webcams -Dresden-", command=button_vorlagen_2)
vorlagen_menu.add_command(label="Minecraft Server -Chemnitz-", command=button_vorlagen_3)
vorlagen_menu.add_command(label="Windows XP Geraete -Deutschland-", command=button_vorlagen_4)
vorlagen_menu.add_command(label="Windows XP Geraete -Firma:Siemens-", command=button_vorlagen_5)
vorlagen_menu.add_command(label="IoT Geraete des FBI", command=button_vorlagen_6)
vorlagen_menu.add_command(label="IoT Geraete Blizzard Company", command=button_vorlagen_7)
vorlagen_menu.add_command(label="Windows XP Geraete", command=button_vorlagen_8)
vorlagen_menu.add_command(label="Screenshots RTSP (Webcam)", command=button_vorlagen_9)
vorlagen_menu.add_command(label="Port:8333 -Deutschland- (Bitcoin) ", command=button_vorlagen_10)
vorlagen_menu.add_command(label="Port:21 -Mittweida- (FTP)", command=button_vorlagen_11)
vorlagen_menu.add_command(label="Port:69 -Mittweida- (BitTorrent)", command=button_vorlagen_12)

kamerka = Menu(menuleiste, tearoff=0)
kamerka.add_command(label="Webcams Deutschland",command=button_kamenka_webcams_germany)

eingabefeld = Entry(fenster, bd=5, width=40)                                          #Erstellen des Eingabefeldes
button_suchen = Button(fenster, text="Suchen", command=button_suchen, fg="red")       #Erstellen Button Suche und Beenden
button_end = Button(fenster, text="Beenden", command=fenster.quit)
button_delete_input = Button(fenster, text="Eingabe Loeschen", command=button_eingabe_loeschen)

logo_hs = PhotoImage(file="logo_hs.gif")                                         
w1 = Label(fenster, image=logo_hs)
logo_Shodan = PhotoImage(file="shodan.gif")
w2 = Label(fenster, image=logo_Shodan)

anweisungs_label=Label(fenster, text="")                                    

menuleiste.add_cascade(label="Info", menu=info_menu)                        #Anordnen der Ellement durch .pack
menuleiste.add_cascade(label="Vorlagen", menu=vorlagen_menu)
menuleiste.add_cascade(label="Kamerka", menu=kamerka) 
anweisungs_label.pack()                                                     #alles noch aendern auf .grind
abfrage_label.pack()
eingabefeld.pack()
button_suchen.pack()
button_end.pack()
welcome_label.pack()
button_delete_input.pack()
w1.pack(side="right")
w2.pack(side="left")

fenster.config(menu=menuleiste)
fenster.mainloop()                                                          #Endlosschleife Fenster, bis durch User 
                                                                            # die Eingabe erfolgt

