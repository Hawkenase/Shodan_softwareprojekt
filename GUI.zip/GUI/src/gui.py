# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "Florian Klaus und Daniel Paasch"
__date__ = "$22.11.2018 13:40:24$"

from tkinter import *
from tkinter import messagebox


def button_suchen():
    abfrage_text = eingabefeld.get()
    if (abfrage_text == ""):
        welcome_label.config(text="Es wird eine Eingabe benoetigt")
    else:
        abfrage = abfrage_text
        print(abfrage)
    
        
def action_get_info_dialog():
    m_text = "\
    *************************************************\n\
    Autoren:       Florian Klaus und Daniel Paasch\n\
    Seminargruppe:   FO16w3-B         FO16w5-B\n\
    Aufgabe:        Softwareprojekt WS 18/19 \n\
    Dozent:         Prof. Dr. Dirk Pawlaszcyk \n\
    *************************************************"
    messagebox.showinfo(message=m_text, title="Info")

def button_vorlagen_1():
    abfrage = "Webcam"
    print(abfrage)        
def button_vorlagen_2():
    abfrage = "Flo ist doof"
def button_vorlagen_3():
    abfrage = "Daniel rulez"
def button_vorlagen_4():
    abfrage = "XXX"
def button_vorlagen_5():
    abfrage = "Hummi"
def button_vorlagen_6():
    abfrage = "Pawel"
    
fenster = Tk()
fenster.title("Shodan")
fenster.geometry("800x500")


menuleiste = Menu(fenster)                                                  #Erstellen der Menueleiste
info_menu = Menu(menuleiste, tearoff=0)
info_menu.add_command(label="Entwickler", command=action_get_info_dialog)

abfrage_label = Label(fenster, text="Bitte geben Sie ihre Suchanfrage ein") #Label Suchfeld
welcome_label = Label(fenster)

eingabefeld = Entry(fenster, bd=5, width=40)                                #Erstellen des Eingabefeldes

                                         #Erstellen des Dropoff-Meues fuer vorgegebene
vorlagen_menu = Menu(menuleiste, tearoff=0)                        #Abfragen
vorlagen_menu.add_command(label="Webcam", command=button_vorlagen_1)
vorlagen_menu.add_command(label="Flo ist doof", command=button_vorlagen_2)
vorlagen_menu.add_command(label="Daniel rulez", command=button_vorlagen_3)
vorlagen_menu.add_command(label="XXX", command=button_vorlagen_4)
vorlagen_menu.add_command(label="Pawel", command=button_vorlagen_5)
vorlagen_menu.add_command(label="Hummi", command=button_vorlagen_6)

button_suchen = Button(fenster, text="Suchen", command=button_suchen, fg="red")       #Erstellen Button Suche und Beenden
button_end = Button(fenster, text="Beenden", command=fenster.quit)

logo_hs = PhotoImage(file="logo_hs.gif")
w1 = Label(fenster, image=logo_hs).pack(side="right")
logo_Shodan = PhotoImage(file="shodan.gif")
w2 = Label(fenster, image=logo_Shodan).pack(side="left")

anweisungs_label=Label(fenster, text="")                                    #

menuleiste.add_cascade(label="Info", menu=info_menu)                        #Anordnen der Ellement durch .pack
menuleiste.add_cascade(label="Vorlagen", menu=vorlagen_menu)
anweisungs_label.pack()                                                     #alles noch aendern auf .grind
abfrage_label.pack()
eingabefeld.pack()
button_suchen.pack()
button_end.pack()
welcome_label.pack()

fenster.config(menu=menuleiste)
fenster.mainloop()                                                          #Endlosschleife Fenster, bis durch User 
                                                                            # die Eingabe erfolgt

