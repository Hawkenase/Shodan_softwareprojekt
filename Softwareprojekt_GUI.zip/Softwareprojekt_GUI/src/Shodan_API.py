__author__ = "Florian Klaus & Daniel Paasch"
__date__ = "$19.11.2018 14:06:27$"

import shodan


    
SHODAN_API_KEY = "V8kcW56VkPG3xF5modxydH45wPY0W7ft"
api = shodan.Shodan(SHODAN_API_KEY)


# Wrap the request in a try/ except block to catch errors
    
   
        #Eingabe User
        #query = input(softwareprojekt_gui.input_user)
        
def query():           
        # Search Shodan
        results = api.search(softwareprojekt_gui.input_user)
    
    try:    
        # Show the results
        print('Results found: {}'.format(results['total']))
        for result in results['matches']:
            file = open("Ergebnis.txt","a")
            file.write('\nIP: {}'.format(result['ip_str']))
            file.write('\nPort: {}'.format(result['port']))
            file.write('\nOrganisation: {}'.format(result['org']))
            file.write('\nBetriebsystem: {}'.format(result['os']))
            file.write('\nLand: {}'.format(result['location']))
            file.write('')
            file.write('\n')
                
        
    except shodan.APIError. e:
        print('Error: {}'.format(e))
