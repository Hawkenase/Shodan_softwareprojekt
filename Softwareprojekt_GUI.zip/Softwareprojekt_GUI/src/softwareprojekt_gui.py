# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

__author__ = "Florian Klaus & Daniel Paasch"
__date__ = "$21.11.2018 12:35:12$"

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import *
from PyQt5.QtCore import *




class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.initMe() 
        
    #def get_input(self):
        #return self.input_user                          #holen des Userinputs
    
    #def set_input(self, input):
        #if input =="":
            #print ("Bitte geben Sie eine Abfrage ein")
        #else:
            #self.input_user = input
    
    def gedrueckt(self):
        Shodan_API.query.set()  #Aktion wenn Button "Suchen" gedrueckt wird
            
    def input(self, text):
        input_user = self.w.text()      #speichern der Anfrage im Textfeld in input_user
        return input_user  
        
        
    def initMe(self):
        QToolTip.setFont(QFont('Arial, 10'))            #Button fuer die Suche
        button_suche = QPushButton('Suchen',self)
        button_suche.move(200,250)
        button_suche.setToolTip('Startet die Suche')
        button_suche.clicked.connect(self.gedrueckt)
        
        self.w = QLineEdit(self)                #Inputfeld Useranfrage
        self.w.move(175,200)                    
        self.w.textChanged.connect(self.input)  
        
        self.label = QtWidgets.QLabel(self)
        self.label.setGeometry(QtCore.QRect(115, 160, 321, 31))
        self.label.setText("Bitte geben Sie ihre gewuenschte Anfrage in das Suchfeld ein.")
        
        QToolTip.setFont(QFont('Arial, 10'))        #Button fuer das Beenden
        button_end = QPushButton('Beenden',self)
        button_end.move(200,300)
        button_end.setToolTip('beendet das Programm')
        button_end.clicked.connect(QtCore.QCoreApplication.instance().quit)
        
        self.setGeometry(100,100,500,500)    #erzeugen des Fensters 
        self.setWindowTitle("Shodan")        #festlegen des Fenstertitels
        
        self.setWindowIcon(QIcon("Image_1.png"))  #festlegen des Fenstericons
        self.show()
        
    

if __name__ == '__main__':        
    app = QApplication(sys.argv)
    w = Window()
    sys.exit(app.exec())